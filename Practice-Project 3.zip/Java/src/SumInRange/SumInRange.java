package SumInRange;

	public class SumInRange {
	    public static void main(String[] args) {
	        int[] numbers = {3, 5, 4, 2, 9, 1, 7, 8, 6};
	        int n = numbers.length;
	        int L = 4;  // Start index of the range
	        int R = 7;  // End index of the range

	        int sum = getSumInRange(numbers, n, L, R);
	        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
	    }

	    public static int getSumInRange(int[] numbers, int n, int L, int R) {
	        if (L < 0 || R >= n || L > R) {
	            throw new IllegalArgumentException("Invalid range");
	        }

	        int sum = 0;
	        for (int i = L; i <= R; i++) {
	            sum += numbers[i];
	        }

	        return sum;
	    }
	}



