package Main_;

class Node {
    int data;
    Node previous;
    Node next;

    public Node(int data) {
        this.data = data;
        this.previous = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    Node head;

    // Function to insert a new node at the end of the doubly linked list
    void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.previous = current;
        }
    }

    // Function to traverse the doubly linked list in the forward direction
    void traverseForward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        System.out.print("Forward traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // Function to traverse the doubly linked list in the backward direction
    void traverseBackward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        System.out.print("Backward traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.previous;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        // Inserting nodes into the doubly linked list
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        // Traversing the list in forward direction
        list.traverseForward();

        // Traversing the list in backward direction
        list.traverseBackward();
    }
}



