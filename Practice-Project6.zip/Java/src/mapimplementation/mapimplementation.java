package mapimplementation;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class mapimplementation {
	public static void main(String[] args) {
		
		Map<String, Integer> hashMap = new HashMap<>();
		hashMap.put("Yellow", 1);
		hashMap.put("Orange", 2);
		hashMap.put("Blue", 3);
		
		System.out.println("HashMap:");
		for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
			String color = entry.getKey();
			int quantity = entry.getValue();
			System.out.println(color + " - " + quantity);
		}
		
		Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
		linkedHashMap.put("Yellow", 1);
		linkedHashMap.put("Orange", 2);
		linkedHashMap.put("Blue", 3);
		
		System.out.println("\nLinkedHashMap:");
		for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
			String color = entry.getKey();
			int quantity = entry.getValue();
			System.out.println(color + " - " + quantity);
		}
		
	}

}
