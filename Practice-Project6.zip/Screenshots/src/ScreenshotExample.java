import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

public class ScreenshotExample {
    public static void main(String[] args) {
        // Set up the WebDriver for Chrome
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
        
        // Set Chrome options (browser profile)
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized"); // Maximize the browser window

        WebDriver driver = new ChromeDriver(options);

        try {
            // Navigate to a web page
            driver.get("https://example.com");

            // Take a screenshot
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Save the screenshot to a file
            FileUtils.copyFile(screenshotFile, new File("screenshot.png"));
            System.out.println("Screenshot saved as 'screenshot.png'");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Close the WebDriver
            driver.quit();
        }
    }
}

