package Car;

public class Engine {
    public void start() {
        System.out.println("Engine started.");
    }
}
