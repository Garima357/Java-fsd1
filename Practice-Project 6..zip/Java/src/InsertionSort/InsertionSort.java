package InsertionSort;

public class InsertionSort {

	    public static void insertionSort(int[] arr) {
	        int n = arr.length;

	        for (int i = 1; i < n; i++) {
	            int key = arr[i];
	            int j = i - 1;

	            // Shift elements greater than key to the right
	            while (j >= 0 && arr[j] > key) {
	                arr[j + 1] = arr[j];
	                j--;
	            }

	            // Place the key at its correct position
	            arr[j + 1] = key;
	        }
	    }

	    public static void main(String[] args) {
	        int[] numbers = { 43, 54, 18, 43, 92, 85, 51};

	        System.out.println("Original array:");
	        printArray(numbers);

	        insertionSort(numbers);

	        System.out.println("Sorted array:");
	        printArray(numbers);
	    }

	    public static void printArray(int[] arr) {
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }
	}



