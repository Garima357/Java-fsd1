package SelectionSort;

public class SelectionSort {
	
	    public static void selectionSort(int[] arr) {
	        int n = arr.length;

	        for (int i = 0; i < n - 1; i++) {
	            int minIndex = i;

	            // Find the index of the minimum element in the unsorted part of the array
	            for (int j = i + 1; j < n; j++) {
	                if (arr[j] < arr[minIndex]) {
	                    minIndex = j;
	                }
	            }

	            // Swap the minimum element with the current element at index i
	            int temp = arr[i];
	            arr[i] = arr[minIndex];
	            arr[minIndex] = temp;
	        }
	    }

	    public static void main(String[] args) {
	        int[] numbers = { 18, 43, 65, 85, 51 };

	        System.out.println("Original array:");
	        printArray(numbers);

	        selectionSort(numbers);

	        System.out.println("Sorted array:");
	        printArray(numbers);
	    }

	    public static void printArray(int[] arr) {
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }
	}



