package FourthSmallestElement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

   

public class FourthSmallestElement {
	

	    public static void main(String[] args) {
	        List<Integer> numbers = new ArrayList<>();
	        numbers.add(1);
	        numbers.add(2);
	        numbers.add(3);
	        numbers.add(4);
	        numbers.add(8);
	        numbers.add(6);
	        numbers.add(7);
	        numbers.add(10);
	        numbers.add(5);
	        numbers.add(9);

	        int fourthSmallest = findFourthSmallest(numbers);
	        System.out.println("Fourth smallest element: " + fourthSmallest);
	    }

	    public static int findFourthSmallest(List<Integer> numbers) {
	        if (numbers.size() < 5) {
	            throw new IllegalArgumentException("List must contain at least 4 elements");
	        }

	        List<Integer> sortedList = new ArrayList<>(numbers);
	        Collections.sort(sortedList);

	        return sortedList.get(4);
	    }
	}


