package MyGenericServlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class MyGenericServlet
 */
@WebServlet("/MyGenericServlet")
public class MyGenericServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyGenericServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

}
