import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;

public class SeleniumGridExample {

    public static void main(String[] args) {
        // Define the URL of the Selenium Grid Hub
        String hubUrl = "http://localhost:4444/wd/hub"; // Replace with your Hub URL

        // Define desired capabilities for different browsers and platforms
        DesiredCapabilities chromeCapabilities = DesiredCapabilities.chrome();
        DesiredCapabilities firefoxCapabilities = DesiredCapabilities.firefox();
        DesiredCapabilities edgeCapabilities = DesiredCapabilities.edge();
        // You can add more desired capabilities as needed

        try {
            // Create WebDriver instances for different browsers
            WebDriver chromeDriver = new RemoteWebDriver(new URL(hubUrl), chromeCapabilities);
            WebDriver firefoxDriver = new RemoteWebDriver(new URL(hubUrl), firefoxCapabilities);
            WebDriver edgeDriver = new RemoteWebDriver(new URL(hubUrl), edgeCapabilities);

            // Test with Chrome
            chromeDriver.get("https://www.example.com");
            System.out.println("Chrome Title: " + chromeDriver.getTitle());
            chromeDriver.quit();

            // Test with Firefox
            firefoxDriver.get("https://www.example.com");
            System.out.println("Firefox Title: " + firefoxDriver.getTitle());
            firefoxDriver.quit();

            // Test with Edge
            edgeDriver.get("https://www.example.com");
            System.out.println("Edge Title: " + edgeDriver.getTitle());
            edgeDriver.quit();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
