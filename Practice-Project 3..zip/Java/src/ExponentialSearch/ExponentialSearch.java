package ExponentialSearch;

public class ExponentialSearch {
	
	    public static int exponentialSearch(int[] arr, int target) {
	        if (arr[0] == target) {
	            return 0; // Return the index 0 if the target is found at the first position
	        }

	        int i = 1;
	        while (i < arr.length && arr[i] <= target) {
	            i *= 2; // Double the value of i for each iteration
	        }

	        return binarySearch(arr, target, i / 2, Math.min(i, arr.length - 1));
	    }

	    public static int binarySearch(int[] arr, int target, int left, int right) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target) {
	                return mid; // Return the index where the target is found
	            }

	            if (arr[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; // Return -1 if the target is not found
	    }

	    public static void main(String[] args) {
	        int[] numbers = {12, 34, 45, 67, 89, 90 };
	        int target = 45;

	        int index = exponentialSearch(numbers, target);

	        if (index != -1) {
	            System.out.println("Target found at index " + index);
	        } else {
	            System.out.println("Target not found");
	        }
	    }
	}



