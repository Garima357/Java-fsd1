package DeleteFirstOccurrence;

public class DeleteFirstOccurrence {
	class Node {
	    int data;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class LinkedList {
	    Node head;

	    public void insert(int data) {
	        Node newNode = new Node(data);

	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	        }
	    }

	    public void delete(int key) {
	        if (head == null) {
	            return;
	        }

	        if (head.data == key) {
	            head = head.next;
	            return;
	        }

	        Node current = head;
	        Node previous = null;

	        while (current != null && current.data != key) {
	            previous = current;
	            current = current.next;
	        }

	        if (current == null) {
	            return;
	        }

	        previous.next = current.next;
	    }

	    public void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }
	}

	    public static void main(String[] args) {
	        LinkedList list = new LinkedList();

	        list.insert(20);
	        list.insert(80);
	        list.insert(60);
	        list.insert(40);
	        list.insert(50);
	        list.insert(20); // Duplicate key

	        System.out.println("Original List:");
	        list.display();

	        int key = 30;
	        list.delete(key);

	        System.out.println("List after deleting first occurrence of key " + key + ":");
	        list.display();
	    }
	}


