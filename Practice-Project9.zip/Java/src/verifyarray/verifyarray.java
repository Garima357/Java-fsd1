package verifyarray;

public class verifyarray {
	public static void main(String[] args) {
		
		int[] num = {1, 2, 3, 4, 5};
		System.out.println("array of interger:");
		for (int i=0; i< num.length; i++) {
			System.out.println(num[i]);
		}
		String[] Names = {"Tom", "Henry", "John", "Robert"};
		
		System.out.println("\narray of strings:");
		for (int i=0; i< Names.length; i++) {
			System.out.println(Names[i]);
		
		}
			
	}

}
