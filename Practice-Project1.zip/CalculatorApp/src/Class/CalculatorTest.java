package Class;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculatorTest {
    private Calculator calculator = new Calculator();

    @Test
    public void testAddition() {
        assertEquals(5, calculator.add(2, 3));
        assertEquals(0, calculator.add(0, 0));
        assertEquals(0, calculator.add(-5, 5));
    }

    @Test
    public void testSubtraction() {
        assertEquals(3, calculator.subtract(5, 2));
        assertEquals(0, calculator.subtract(10, 10));
        assertEquals(0, calculator.subtract(-5, -5));
    }
}


