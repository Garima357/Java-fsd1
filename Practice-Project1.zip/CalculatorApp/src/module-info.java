/**
 * 
 */
/**
 * 
 */
module CalculatorApp {
	requires junit;
}