package implicit_explicit;

public class Implicit_Explicit1 {
	public static void main(String args[])
	{
		byte a=20;
		// no other casting needed
		short b=a;
		int c=b;
		long d=c;
		float e=d;
		double f=e;
		
		System.out.println("byte value : "+a);
		System.out.println("short value : "+b);
		System.out.println("int value : "+c);
		System.out.println("long value : "+d);
		System.out.println("float value : "+e);
		System.out.println("double value : "+f);
	}

}
