import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;

public class SeleniumGridExample {
    public static void main(String[] args) {
        try {
            // Define desired capabilities for the browser and platform you want to test on
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setBrowserName("chrome"); // Use "firefox" for Firefox, and so on
            // Other capabilities (e.g., platform, version) can be set as needed

            // Remote WebDriver URL
            URL gridUrl = new URL("http://localhost:4444/wd/hub"); // Replace with your Hub URL

            // Create a remote WebDriver instance
            WebDriver driver = new RemoteWebDriver(gridUrl, capabilities);

            // Your Selenium test script here
            driver.get("https://example.com");
            System.out.println("Title: " + driver.getTitle());

            // Close the browser
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

