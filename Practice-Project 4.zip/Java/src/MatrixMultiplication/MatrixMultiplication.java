package MatrixMultiplication;

public class MatrixMultiplication {
	    public static void main(String[] args) {
	        int[][] matrix1 = {
	            {1, 2, 3},
	            {4, 5, 6},
	            {7, 8, 9}
	        };

	        int[][] matrix2 = {
	            {10, 11},
	            {12, 13},
	            {14, 15}
	        };

	        int[][] result = multiplyMatrices(matrix1, matrix2);

	        System.out.println("Matrix 1:");
	        printMatrix(matrix1);

	        System.out.println("Matrix 2:");
	        printMatrix(matrix2);

	        System.out.println("Matrix Multiplication Result:");
	        printMatrix(result);
	    }

	    public static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2) {
	        int m1Rows = matrix1.length;
	        int m1Cols = matrix1[0].length;
	        int m2Rows = matrix2.length;
	        int m2Cols = matrix2[0].length;

	        if (m1Cols != m2Rows) {
	            throw new IllegalArgumentException("Cannot multiply matrices. Incompatible dimensions.");
	        }

	        int[][] result = new int[m1Rows][m2Cols];

	        for (int i = 0; i < m1Rows; i++) {
	            for (int j = 0; j < m2Cols; j++) {
	                int sum = 0;
	                for (int k = 0; k < m1Cols; k++) {
	                    sum += matrix1[i][k] * matrix2[k][j];
	                }
	                result[i][j] = sum;
	            }
	        }

	        return result;
	    }

	    public static void printMatrix(int[][] matrix) {
	        for (int[] row : matrix) {
	            for (int element : row) {
	                System.out.print(element + " ");
	            }
	            System.out.println();
	        }
	        System.out.println();
	    }
	}



