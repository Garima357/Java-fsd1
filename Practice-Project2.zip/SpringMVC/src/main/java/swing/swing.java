import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventHandlingDemo extends JFrame {

    private JButton button;

    public EventHandlingDemo() {
        super("Event Handling Demo");
        initialize();
    }

    private void initialize() {
        // Set up the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        // Create a button
        button = new JButton("Click Me!");

        // Add default event handling (ActionListener)
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(EventHandlingDemo.this, "Default Event Handling: Button clicked!");
            }
        });

        // Add custom event handling (CustomActionListener)
        button.addActionListener(new CustomActionListener());

        // Add the button to the frame
        getContentPane().setLayout(new FlowLayout());
        getContentPane().add(button);
    }

    // Custom ActionListener class for custom event handling
    private class CustomActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(EventHandlingDemo.this, "Custom Event Handling: Button clicked!");
        }
    }

    public static void main(String[] args) {
        // Create and show the GUI
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EventHandlingDemo().setVisible(true);
            }
        });
    }
}

