package access_modifiers;

public class access_modifiers {
	
	public static void main(String[] args) {
		MyClass obj = new MyClass();
		obj.publicMethod();
		obj.defaultMethod();
		obj.protectedMethod();
		
	}

}

class MyClass {
	public void publicMethod() {
		System.out.println("this is public method");
		
	}
	
	void defaultMethod() {
		System.out.println("this is default method");
		
	}
	
	private void privateMethod() {
		System.out.println("this is private method");
	}
	protected void protectedMethod() {
		System.out.println("this is protected method");
		
	}
}
