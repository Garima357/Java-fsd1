<!DOCTYPE html>
<html>
<head>
    <title>JSP Implicit Objects</title>
</head>
<body>
    <h1>JSP Implicit Objects</h1>
    <p>Current Date and Time: <%= new java.util.Date() %></p>
    <p>Request Method: <%= request.getMethod() %></p>
    <p>Client IP Address: <%= request.getRemoteAddr() %></p>
    <p>Server Name: <%= request.getServerName() %></p>
    <p>Server Port: <%= request.getServerPort() %></p>
    <p>Request URI: <%= request.getRequestURI() %></p>
    <p>Servlet Context Path: <%= request.getContextPath() %></p>
    <p>Session ID: <%= session.getId() %></p>
    <p>User Agent: <%= request.getHeader("User-Agent") %></p>
    <p>Query String: <%= request.getQueryString() %></p>
</body>
</html>

