package Class;
public class AssertionDemo {

    public static void main(String[] args) {
        int num = 10;
        assert num >= 0 : "Number cannot be negative";
        
        System.out.println("Number: " + num);
        
        int result = divide(10, 2);
        assert result == 5 : "Divide method returned incorrect result";
        
        System.out.println("Result: " + result);
    }

    public static int divide(int dividend, int divisor) {
        assert divisor != 0 : "Cannot divide by zero";
        return dividend / divisor;
    }
}

