package regular_expression;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class regular_expression {
	public static void main(String[] args) {
		
		String regex = "[a-zA-Z]+";
		
		String str1 = "Hii";
		String str2 = "345";
		String str3 = "Hii345";
		
		Pattern pattern = Pattern.compile(regex);
		
		
		System.out.println("input: " + str1);
		Matcher matcher1 = pattern.matcher(str1);
		System.out.println("Matches: " + matcher1.matches());
		
		System.out.println("input: " + str2);
		Matcher matcher2 = pattern.matcher(str2);
		System.out.println("Matches: " + matcher2.matches());
		
		
		System.out.println("input: " + str3);
		Matcher matcher3 = pattern.matcher(str3);
		System.out.println("Matches: " + matcher3.matches());
		
	
	}

}
