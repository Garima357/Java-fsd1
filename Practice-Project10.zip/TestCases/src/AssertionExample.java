import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionExample {

    @Test
    public void testWithHardAssertions() {
        int actualValue = 5;
        int expectedValue = 5;
        
        // Hard Assertion: If this fails, the test stops immediately
        Assert.assertEquals(actualValue, expectedValue, "Values don't match!");
        
        System.out.println("This line will be executed if the hard assertion passes.");
    }

    @Test
    public void testWithSoftAssertions() {
        int actualValue = 5;
        int expectedValue = 7;
        
        // Soft Assertions: All soft assertions are executed even if some fail
        // Create a soft assertion instance
        SoftAssert softAssert = new SoftAssert();
        
        softAssert.assertEquals(actualValue, expectedValue, "Values don't match!");
        
        // You can add more soft assertions here
        
        // Assert all soft assertions
        softAssert.assertAll();
        
        System.out.println("This line will be executed even if some soft assertions fail.");
    }
}
