package JDBCDemo;

import java.sql.*;

public class JDBCDemo {
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // Establish a connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306", "username", "password");

            // Create a new database
            statement = connection.createStatement();
            String createDatabaseQuery = "CREATE DATABASE mydatabase";
            statement.executeUpdate(createDatabaseQuery);
            System.out.println("Database created successfully!");

            // Select the created database
            String useDatabaseQuery = "USE mydatabase";
            statement.executeUpdate(useDatabaseQuery);
            System.out.println("Database selected successfully!");

            // Perform operations in the selected database

            // Drop the database
            String dropDatabaseQuery = "DROP DATABASE mydatabase";
            statement.executeUpdate(dropDatabaseQuery);
            System.out.println("Database dropped successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the resources
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
