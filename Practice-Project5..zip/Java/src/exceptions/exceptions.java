package exceptions;
class MyException extends Exception {
	public MyException(String message) {
		super(message);
	}
}

public class exceptions {
	public static void main(String[] args) {
		try {
			divide(20,0);
		} catch (ArithmeticException e) {
			System.out.println("ArithmeticExpression caught: " + e.getMessage());
		} catch (MyException e) {	
			System.out.println("MyExpression caught: " + e.getMessage());
		} finally {
			System.out.println("Finally block executes");
			
		}
		
		System.out.println("Program execution continues...");
		
	}
	
	public static int divide(int numerator, int denominator) throws ArithmeticException, MyException {
		try {
			if (denominator ==0) {
				throw new ArithmeticException("Devision by zero is not allowed");
				
			}
			return numerator / denominator;
		} catch (ArithmeticException e) {
			throw e;
		} finally {
			throw new MyException("Exception thrown in the finally block");
			
		}
	}

}
