package Class;

import static org.junit.Assert.assertEquals;
import org.junit.Assume;
import org.junit.Test;

public class CalculatorTest {

    @Test
    public void testAddition() {
        int result = add(2, 3);
        assertEquals(5, result);
    }

    @Test
    public void testSubtraction() {
        int result = subtract(5, 2);
        assertEquals(3, result);
    }

    @Test
    public void testDivision() {
        int result = divide(10, 2);
      
        Assume.assumeTrue(result == 5);
        
        
        System.out.println("Division result is 5: " + result);
    }

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
}
