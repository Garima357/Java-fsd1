/**
 * 
 */
/**
 * 
 */
module ConditionalTestExecutionDemo {
	requires junit;
}