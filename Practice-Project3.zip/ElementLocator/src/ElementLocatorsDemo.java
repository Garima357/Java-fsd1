import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementLocatorsDemo {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");

        // Initialize WebDriver, open a web page, and maximize the browser window
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.example.com");
        driver.manage().window().maximize();

        try {
            // Locate an element by ID
            WebElement elementById = driver.findElement(By.id("elementId"));
            elementById.click(); // Click on the element by ID

            // Locate an element by Name
            WebElement elementByName = driver.findElement(By.name("elementName"));
            elementByName.sendKeys("Hello, World!"); // Type text into the element by Name

            // Locate an element by XPath
            WebElement elementByXPath = driver.findElement(By.xpath("//xpath-expression"));
            String textFromXPath = elementByXPath.getText(); // Get the text from the element by XPath
            System.out.println("Text from XPath: " + textFromXPath);

            // Locate an element by CSS Selector
            WebElement elementByCssSelector = driver.findElement(By.cssSelector("css-selector"));
            // Perform an action on the element by CSS Selector (e.g., click)

            // Locate an element by Link Text
            WebElement elementByLinkText = driver.findElement(By.linkText("Link Text"));
            // Perform an action on the element by Link Text (e.g., click)

            // Locate an element by Partial Link Text
            WebElement elementByPartialLinkText = driver.findElement(By.partialLinkText("Partial Link Text"));
            // Perform an action on the element by Partial Link Text (e.g., click)

            // Locate an element by Class Name
            WebElement elementByClassName = driver.findElement(By.className("className"));
            // Perform an action on the element by Class Name (e.g., click)

            // Continue with additional actions or assertions as needed

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser and clean up WebDriver resources
            driver.quit();
        }
    }
}
