package javax.persistence;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AddProductservlet")
public class AddProductservlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        // Get other form fields as needed

        // Perform form validation
        if (name == null || name.isEmpty()) {
            response.getWriter().println("Please enter a valid name.");
            return;
        }

        // Create a new product object
        Product product = new Product();
        product.setName(name);
        // Set other attributes as needed

        // Save the product to the database
        ProductDAO productDAO = new ProductDAO();
        productDAO.addProduct(product);

        // Redirect back to the form or show a success message
        response.sendRedirect("add-product.html");
    }
}
