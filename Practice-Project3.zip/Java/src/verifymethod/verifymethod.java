package verifymethod;

public class verifymethod {
	
	public static void main(String[] args) {
		int result =addnum(10,15);
		if (result ==25) {
			System.out.println("addnum() method is correct");
		} else {
			System.out.println("addnum() method is not correct");
		}
		
		displaymsg();
		int sum = calculateSum(3, 4, 5, 6, 7);
		System.out.println("Sum: " + sum);
		
		String fullName = getFullName("Tom", "Henry");
		System.out.println("Full Name: " + fullName);
	}
	
	public static int addnum(int a, int b) {
		return a+b;
	}
	
	public static void displaymsg() {
		System.out.println("Hii everyone");
	}
	
	public static int calculateSum(int...num) {
		int sum = 0;
		for (int numbers : num) {
			sum += numbers; 
		}
		return sum;
		
		
	}
	
	public static String getFullName(String firstName, String lastName) {
		return firstName + " " + lastName;
	
	}

}
