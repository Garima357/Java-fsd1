<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP Directives</title>
</head>
<body>
    <h1>JSP Directives</h1>
    <p>Welcome, <%= request.getParameter("name") %>!</p>
    
    <%-- JSP Scriptlet --%>
    <% if (request.getParameter("age") != null) { %>
        <% int age = Integer.parseInt(request.getParameter("age")); %>
        <% if (age >= 18) { %>
            <p>You are an adult.</p>
        <% } else { %>
            <p>You are a minor.</p>
        <% } %>
    <% } %>
    
    <%-- JSP Expression --%>
    <p>Your lucky number is: <%= Math.random() * 100 %></p>
    
    <%-- JSP Declaration --%>
    <%!
        private String greet(String name) {
            return "Hello, " + name + "!";
        }
    %>
    <p><%= greet(request.getParameter("name")) %></p>
    
    <%-- JSP Include Directive --%>
    <%@ include file="included.jsp" %>
    
    <%-- JSP Taglib Directive --%>
    <c:if test="${empty request.getParameter('name')}">
        <p>No name provided.</p>
    </c:if>
</body>
</html>

