import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class JdbcSpringIntegrationDemo {

    public static void main(String[] args) {
        // Set up the database connection
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/your_database_name");
        dataSource.setUsername("your_username");
        dataSource.setPassword("your_password");

        // Create JdbcTemplate instance using the data source
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        // Insert a new employee
        String insertQuery = "INSERT INTO employees (name, designation, salary) VALUES (?, ?, ?)";
        jdbcTemplate.update(insertQuery, "John Doe", "Software Engineer", 50000);

        // Fetch all employees
        String selectQuery = "SELECT * FROM employees";
        List<Employee> employees = jdbcTemplate.query(selectQuery, (resultSet, rowNum) -> {
            Employee employee = new Employee();
            employee.setId(resultSet.getInt("id"));
            employee.setName(resultSet.getString("name"));
            employee.setDesignation(resultSet.getString("designation"));
            employee.setSalary(resultSet.getDouble("salary"));
            return employee;
        });

        // Display the list of employees
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}

class Employee {
    private int id;
    private String name;
    private String designation;
    private double salary;

    // Getters and setters

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", designation='" + designation + '\'' +
                ", salary=" + salary +
                '}';
    }
}
