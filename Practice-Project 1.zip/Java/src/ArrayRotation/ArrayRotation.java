package ArrayRotation;

import java.util.Arrays;

public class ArrayRotation {
	
	    public static void main(String[] args) {
	        int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

	        System.out.println("Original Array: " + Arrays.toString(array));

	        int rotationSteps = 5;
	        rightRotateArray(array, rotationSteps);

	        System.out.println("Rotated Array: " + Arrays.toString(array));
	    }

	    public static void rightRotateArray(int[] arr, int steps) {
	        int length = arr.length;
	        steps = steps % length;  // Adjust steps if greater than array length

	        reverseArray(arr, 0, length - 1);
	        reverseArray(arr, 0, steps - 1);
	        reverseArray(arr, steps, length - 1);
	    }

	    public static void reverseArray(int[] arr, int start, int end) {
	        while (start < end) {
	            int temp = arr[start];
	            arr[start] = arr[end];
	            arr[end] = temp;
	            start++;
	            end--;
	        }
	    }
	}



