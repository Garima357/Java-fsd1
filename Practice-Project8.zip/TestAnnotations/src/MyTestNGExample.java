import org.testng.annotations.*;

public class MyTestNGExample {

    @BeforeSuite
    public void beforeSuite() {
        // Code to execute before the test suite
        System.out.println("Before Suite");
    }

    @BeforeTest
    public void beforeTest() {
        // Code to execute before the test cases within a <test> tag
        System.out.println("Before Test");
    }

    @BeforeClass
    public void beforeClass() {
        // Code to execute before all test methods in the current class
        System.out.println("Before Class");
    }

    @BeforeMethod
    public void beforeMethod() {
        // Code to execute before each test method
        System.out.println("Before Method");
    }

    @Test
    public void testMethod1() {
        // Test method 1 logic
        System.out.println("Test Method 1");
    }

    @Test
    public void testMethod2() {
        // Test method 2 logic
        System.out.println("Test Method 2");
    }

    @AfterMethod
    public void afterMethod() {
        // Code to execute after each test method
        System.out.println("After Method");
    }

    @AfterClass
    public void afterClass() {
        // Code to execute after all test methods in the current class
        System.out.println("After Class");
    }

    @AfterTest
    public void afterTest() {
        // Code to execute after the test cases within a <test> tag
        System.out.println("After Test");
    }

    @AfterSuite
    public void afterSuite() {
        // Code to execute after the test suite
        System.out.println("After Suite");
    }
}

