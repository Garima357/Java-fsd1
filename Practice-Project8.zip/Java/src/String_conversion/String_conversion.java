package String_conversion;

public class String_conversion {
	public static void main(String[] args) {
		String str = "Hii everyone";
		StringBuffer stringBuffer = new StringBuffer(str);
		StringBuilder stringBuilder = new StringBuilder(str);
		
		
		System.out.println("StringBuffer: " + stringBuffer);
		System.out.println("StringBuilder: " + stringBuilder);
		
	}

}
