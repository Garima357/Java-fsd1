package tryandcatch;

public class tryandcatch {
	public static void main(String[] args) {
		int[] numbers = {3, 4, 5, 6, 7 };
		int index = 5;
				
		try {
			int result = numbers[index];
			System.out.println("The value at index " + index + " is: " + result);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Error: Index out of bounds. Provide valid index.");
		}
		
		System.out.println("Program execution continues...");
				
				
	}

}
