package JDBCDemo;
import java.sql.*;

public class JDBCDemo {
    // Database credentials
    static final String DB_URL = "jdbc:mysql://localhost:3306/mydatabase";
    static final String USER = "username";
    static final String PASS = "password";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
            // Step 1: Open a connection to the database
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Step 2: Create a statement object
            stmt = conn.createStatement();

            // Step 3: Insert a record
            String insertQuery = "INSERT INTO employees (id, name, age) VALUES (1, 'John Doe', 30)";
            stmt.executeUpdate(insertQuery);
            System.out.println("Record inserted successfully!");

            // Step 4: Update a record
            String updateQuery = "UPDATE employees SET age = 31 WHERE id = 1";
            stmt.executeUpdate(updateQuery);
            System.out.println("Record updated successfully!");

            // Step 5: Delete a record
            String deleteQuery = "DELETE FROM employees WHERE id = 1";
            stmt.executeUpdate(deleteQuery);
            System.out.println("Record deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Step 6: Close the resources
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
