pipeline {
    agent any
    
    environment {
        MAVEN_HOME = tool 'Maven 3.8.4' // The Maven tool name you configured in Jenkins
    }
    
    stages {
        stage('Checkout') {
            steps {
                // Checkout your source code from version control (e.g., Git)
                checkout scm
            }
        }
        
        stage('Build and Test') {
            steps {
                // Set up the environment variables
                script {
                    def mvnHome = tool name: 'Maven 3.8.4', type: 'hudson.tasks.Maven$MavenInstallation'
                    env.PATH = "${mvnHome}/bin:${env.PATH}"
                }
                
                // Build your Maven project
                sh "mvn clean test"
            }
        }
    }
    
    post {
        always {
            // Archive test reports for later reference (e.g., TestNG reports)
            archiveArtifacts(allowEmptyArchive: true, artifacts: '**/target/surefire-reports/*.xml')
            
            // Publish JUnit test results for Jenkins to display
            junit '**/target/surefire-reports/*.xml'
        }
    }
}

