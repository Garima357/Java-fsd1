package SleepAndWait;

public class SleepAndWait {
	
	public static void main(String[] args) {
		SleepThread sleepThread = new SleepThread();
		WaitThread waitThread = new WaitThread();
		
		sleepThread.start();
		
		synchronized(waitThread) {	
			waitThread.start();
			
			try {
				waitThread.wait();
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
		
    static class SleepThread extends Thread {
    	public void run() {
    		try {
    			System.out.println("SleepThread: Start sleeping...");
    			Thread.sleep(2000);
    			System.out.println("SleepThread: Wake up from sleep.");
    		} catch (InterruptedException e) {
    			e.printStackTrace();
    		}
    	}
    }
    		
    static class WaitThread extends Thread {
    	public void run() {
    		synchronized (this) {
    			try {
    				System.out.println("WaitThread: Start waiting...");
    				wait(2000);
    				System.out.println("WaitThread: Wake up from wait.");
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    			} finally {	
    				notify();
    			}
    		}
    	}
    }
}
    			
    		


    	