package circle;
class circle {
	private double radius;

    public circle (double radius) {
    	this.radius = radius;
    	
    }
    
    public double calculateArea() {
    	return Math.PI * radius * radius;
    }
}
public class OOP {
	public static void main(String[] args) {
		
		circle Circle1 = new circle(10.0);
		circle Circle2 = new circle(5.0);
		
		System.out.println("circle 1: Radius = " + Circle1.calculateArea());
		System.out.println("circle 2: Radius = " + Circle2.calculateArea());
		
		
	}
}
    
    
	



