package hubConfig;

public class Snippet {
	{
	  "port": 4444,
	  "newSessionWaitTimeout": -1,
	  "servlets": [],
	  "prioritizer": null,
	  "capabilityMatcher": "org.openqa.grid.internal.utils.DefaultCapabilityMatcher",
	  "throwOnCapabilityNotPresent": true,
	  "nodePolling": 5000,
	  "cleanUpCycle": 5000,
	  "timeout": 30000,
	  "browserTimeout": 0,
	  "maxSession": 5,
	  "jettyMaxThreads": -1
	}
	
}


{
	  "capabilities": [
	    {
	      "browserName": "chrome",
	      "maxInstances": 5,
	      "platform": "LINUX"
	    },
	    {
	      "browserName": "firefox",
	      "maxInstances": 5,
	      "platform": "LINUX"
	    }
	  ],
	  "proxy": "org.openqa.grid.selenium.proxy.DefaultRemoteProxy",
	  "maxSession": 5,
	  "port": 5555,
	  "register": true,
	  "registerCycle": 5000,
	  "hub": "http://localhost:4444",
	  "nodeStatusCheckTimeout": 5000,
	  "nodePolling": 5000,
	  "role": "node",
	  "unregisterIfStillDownAfter": 60000,
	  "downPollingLimit": 2,
	  "debug": false,
	  "servlets": [],
	  "withoutServlets": [],
	  "custom": {}
	}

