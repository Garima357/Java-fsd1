class MyThread extends Thread {
	public void run() {
		for (int i =0; i<10;i++) {
			System.out.println("Thread using Thread class: " +i);
		}
	}
}

public class Main {
	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.start();
	}
	
}

class MyRunnable implements Runnable  {
	public void run() {
		for (int i =0; i<10;i++) {
			System.out.println("Thread using Runnable interface: " +i);
		}
	}
}

public class SecondMain {
	public static void main(String[] args) {
		MyRunnable myRunnable = new MyRunnable();
		Thread thread = new Thread (myRunnable);
		thread.start();
	}
	
}

