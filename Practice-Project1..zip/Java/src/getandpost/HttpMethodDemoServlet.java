package getandpost;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HttpMethodDemoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Process GET request
        String name = request.getParameter("name");
        response.getWriter().println("Hello, " + name + "! This is a GET request.");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Process POST request
        String name = request.getParameter("name");
        response.getWriter().println("Hello, " + name + "! This is a POST request.");
    }
}
