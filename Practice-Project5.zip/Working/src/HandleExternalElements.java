import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Alert;

import java.util.Set;

public class HandleExternalElements {
    public static void main(String[] args) {
        // Set up the WebDriver for Chrome
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        try {
            // Handling Pop-Up Windows
            driver.get("https://example.com");
            driver.findElement(By.linkText("Open New Window")).click();

            // Get the handles of all open windows
            Set<String> windowHandles = driver.getWindowHandles();

            // Switch to the new window
            for (String handle : windowHandles) {
                driver.switchTo().window(handle);
                if (driver.getTitle().equals("New Window Title")) {
                    break;
                }
            }

            // Perform actions in the new window
            WebElement elementInNewWindow = driver.findElement(By.id("elementId"));
            elementInNewWindow.sendKeys("Handling pop-up windows with Selenium");

            // Switch back to the main window
            driver.switchTo().defaultContent();

            // Handling iframes
            driver.get("https://example.com/with-iframe");

            // Switch to the iframe by name or ID
            driver.switchTo().frame("iframeName");

            // Perform actions inside the iframe
            WebElement iframeElement = driver.findElement(By.id("elementIdInsideIframe"));
            iframeElement.sendKeys("Interacting with elements in an iframe");

            // Switch back to the main content
            driver.switchTo().defaultContent();

            // Handling Alerts
            driver.get("https://example.com/with-alert");

            // Switch to the alert
            Alert alert = driver.switchTo().alert();

            // Accept the alert
            alert.accept();

            // Close the alert
            // alert.dismiss();

            // Get text from the alert
            // String alertText = alert.getText();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the WebDriver
            driver.quit();
        }
    }
}

