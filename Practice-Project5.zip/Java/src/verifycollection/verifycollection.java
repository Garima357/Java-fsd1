package verifycollection;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

public class verifycollection {
	public static void main(String[] args) {
		
		List<String> arrayList = new ArrayList<>();
		arrayList.add("Yellow");
		arrayList.add("orange");
		arrayList.add("Blue");
		
		System.out.println("ArrayList:");
		for (String color : arrayList) {
			System.out.println(color);
			
		}
		
		Set<Integer> hashSet = new HashSet<>();
		hashSet.add(5);
		hashSet.add(10);
		hashSet.add(15);
		
		System.out.println("\nHashSet:");
		for (Integer num : hashSet) {
			System.out.println(num);
		}
			
	}

}
