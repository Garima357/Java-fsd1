<!DOCTYPE html>
<html>
<head>
    <title>Session Handling in JSP</title>
</head>
<body>
    <h1>Session Handling in JSP</h1>
    
    <%-- JSP Scriptlet to create or retrieve session --%>
    <% HttpSession session = request.getSession(); %>
    
    <%-- Check if session is new or existing --%>
    <% if (session.isNew()) { %>
        <p>Welcome, new user!</p>
    <% } else { %>
        <p>Welcome back, <%= session.getAttribute("username") %>!</p>
        <p>Your last visit was: <%= session.getAttribute("lastVisitTime") %></p>
    <% } %>
    
    <%-- JSP Form to handle session data --%>
    <form method="POST" action="sessionHandler.jsp">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">
        <input type="submit" value="Save">
    </form>
</body>
</html>



