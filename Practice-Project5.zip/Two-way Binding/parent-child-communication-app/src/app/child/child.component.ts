import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
})
export class ChildComponent {
  @Input() dataFromParent: string;
  @Output() dataToParent = new EventEmitter<string>();

  sendDataToParent() {
    const newData = 'Hello Parent!';
    this.dataToParent.emit(newData);
  }
}
