package Class;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

public class CalculatorTest {

    @TestFactory
    Collection<DynamicTest> testAddition() {
        return Arrays.asList(
            dynamicTest("Test addition with positive numbers", () -> {
                int result = add(2, 3);
                assertEquals(5, result);
            }),
            dynamicTest("Test addition with zero", () -> {
                int result = add(0, 0);
                assertEquals(0, result);
            }),
            dynamicTest("Test addition with negative numbers", () -> {
                int result = add(-5, -3);
                assertEquals(-8, result);
            })
        );
    }

    @TestFactory
    Collection<DynamicTest> testSubtraction() {
        return Arrays.asList(
            dynamicTest("Test subtraction with positive numbers", () -> {
                int result = subtract(5, 2);
                assertEquals(3, result);
            }),
            dynamicTest("Test subtraction with zero", () -> {
                int result = subtract(10, 10);
                assertEquals(0, result);
            }),
            dynamicTest("Test subtraction with negative numbers", () -> {
                int result = subtract(-5, -3);
                assertEquals(-2, result);
            })
        );
    }

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }
}

