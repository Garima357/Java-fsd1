package Main;


public class Main {
	
	class Node {
	    int data;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class CircularLinkedList {
	    Node head;

	    // Function to insert a new element into a sorted circular linked list
	    void insert(int data) {
	        Node newNode = new Node(data);

	        // If the list is empty, make the new node the head
	        if (head == null) {
	            head = newNode;
	            newNode.next = head;
	            return;
	        }

	        // If the new node is to be inserted before the head
	        if (data < head.data) {
	            newNode.next = head;

	            // Find the last node in the list
	            Node temp = head;
	            while (temp.next != head) {
	                temp = temp.next;
	            }

	            // Make the new node the new head and update the last node's next pointer
	            head = newNode;
	            temp.next = head;
	        } else {
	            Node current = head;

	            // Find the position to insert the new node
	            while (current.next != head && data > current.next.data) {
	                current = current.next;
	            }

	            // Insert the new node
	            newNode.next = current.next;
	            current.next = newNode;
	        }
	    }

	    // Function to display the elements of the circular linked list
	    void display() {
	        if (head == null) {
	            System.out.println("List is empty.");
	            return;
	        }

	        Node current = head;
	        do {
	            System.out.print(current.data + " ");
	            current = current.next;
	        } while (current != head);

	        System.out.println();
	    }
	}

	    public static void main(String[] args) {
	        CircularLinkedList list = new CircularLinkedList();
	        list.insert(10);
	        list.insert(20);
	        list.insert(30);
	        list.insert(40);

	        System.out.println("Original list:");
	        list.display();

	        // Inserting a new element
	        list.insert(25);

	        System.out.println("List after inserting a new element:");
	        list.display();
	    }
	}


