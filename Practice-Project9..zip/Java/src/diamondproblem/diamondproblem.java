package diamondproblem;
interface Animal {
	void eat();
}
interface Mammal extends Animal {
	void walk();
}
interface Reptile extends Animal {
	void crawl();
}

class Platypus implements Mammal, Reptile {
	public void eat() {
	System.out.println("Platypus is eating");
	
}
   public void walk() {
   System.out.println("Platypus is walking");

}
   public void crawl() {
   System.out.println("Platypus is crawling");
   }

}

public class diamondproblem {
	public static void main(String[] args) {
		Platypus platypus = new Platypus();
		platypus.eat();
		platypus.walk();
		platypus.crawl();
		
	}

}
