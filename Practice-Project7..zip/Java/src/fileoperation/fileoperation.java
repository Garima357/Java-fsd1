package fileoperation;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class fileoperation {
	public static void main(String[] args) {
		String filePath = "example.txt";
		
		createFile(filePath);
		String data = "Hi everyone";
		writeToFile(filePath, data);
		
		String fileData = readFromFile(filePath);
		System.out.println("File contents: " + fileData);
		
		String newData = "Updated data";
		updateFile(filePath, newData);
		
		fileData = readFromFile(filePath);
		System.out.println("Updated file contents: " + fileData);
		
		deleteFile(filePath);
		
	}
	
	public static void createFile(String filePath) {
		File file = new File(filePath);
		try {
			if (file.createNewFile()) {
				System.out.println("file created: " + file.getName());
			} else {
				System.out.println("File already exists");
				
			}
		} catch (IOException e) {
			System.out.println("An error occured: " + e.getMessage());
			
		}
	}
	public static void writeToFile(String filePath, String data) {
		try (FileWriter writer = new FileWriter(filePath)) {
			writer.write(data);
			System.out.println("Data written to the file ");
		} catch (IOException e) {
			System.out.println("An error occured: " + e.getMessage());	
		}
	}
    public static String readFromFile(StringfilePath) {
    	StringBuilder content = new StringBuilder();
    	try (BufferedReader reader = new BufferedReader(new FileReader(filePath) {
    		String line;
    		while ((line = reader.readLine()) != null) {
    			content.append(line);
    		}
    	} catch (IOException e) {
    		System,out,println("An error occured: " + e.getMessage());
    		
    	}
    	return content.toString();
    	
    }
    
    public static void updateFile(String filePath, String newData) {
    	try (FileWriter writer = new FileWriter(filePath)) {
    		writer.write(newData);
    		System.out.println("File updated ");
    		
    	} catch (IOException e) {
    		System,out,println("An error occured: " + e.getMessage());
    		
    	}
    }
    public static void deleteFile(String filePath) {
    	FEile file = new File(filePath);
    	if (file.delete()) {
    		System,out,println("File deleted: " + file.getName());
    	} else {
    		System.out.println('Failed to delete the file. ");
    		
    	}
    }
}
