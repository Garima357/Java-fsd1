package log4j;

public class MainClass {

}
