package webelement;

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
import time

# Initialize the WebDriver (choose the appropriate driver for your browser)
driver = webdriver.Chrome()  # Change to webdriver.Firefox() for Firefox

# Navigate to a website
driver.get("https://example.com")

# 1.4.1 Edit Box (Input Field)
edit_box = driver.find_element(By.NAME, "username")
edit_box.send_keys("your_username")

# 1.4.2 Link
link = driver.find_element(By.LINK_TEXT, "Example Link")
link.click()

# 1.4.3 Button
button = driver.find_element(By.ID, "submit_button")
button.click()

# 1.4.4 Image, Image Link, Image Button
image = driver.find_element(By.XPATH, "//img[@alt='Example Image']")
image_link = driver.find_element(By.XPATH, "//a[contains(@href,'example-link')]")
image_button = driver.find_element(By.XPATH, "//input[@type='image']")

# 1.4.5 Text Area
text_area = driver.find_element(By.ID, "textarea_id")
text_area.send_keys("This is a text area")

# 1.4.6 Checkbox
checkbox = driver.find_element(By.ID, "checkbox_id")
if not checkbox.is_selected():
    checkbox.click()

# 1.4.7 Radio Button
radio_button = driver.find_element(By.XPATH, "//input[@type='radio' and @value='option1']")
if not radio_button.is_selected():
    radio_button.click()

# 1.4.8 Dropdown List (Select Element)
dropdown = Select(driver.find_element(By.ID, "dropdown_id"))
dropdown.select_by_visible_text("Option 2")

# 1.4.9 Web Table / HTML Table (Interact with table elements as needed)
table = driver.find_element(By.ID, "table_id")
# Use table.find_elements(By.TAG_NAME, "tr") and table.find_elements(By.TAG_NAME, "td") to access rows and cells

# 1.4.10 Frame
driver.switch_to.frame("frame_name_or_id")  # Switch to a frame by name or ID
# Perform actions inside the frame
driver.switch_to.default_content()  # Switch back to the main content

# Wait for a few seconds (optional)
time.sleep(3)

# Close the browser
driver.quit()

