document.addEventListener('DOMContentLoaded', function () {
    const myButton = document.getElementById('myButton');

    myButton.addEventListener('click', function () {
        alert('Button Clicked!');
    });
});
