<!DOCTYPE html>
<html>
<head>
    <title>JSP Action Tags</title>
</head>
<body>
    <h1>JSP Action Tags</h1>
    
    <%-- JSP UseBean Action --%>
    <jsp:useBean id="person" class="com.example.Person" />
    
    <%-- JSP SetProperty Action --%>
    <jsp:setProperty property="name" value="John Doe" name="person" />
    <jsp:setProperty property="age" value="30" name="person" />
    
    <%-- JSP GetProperty Action --%>
    <p>Name: <jsp:getProperty property="name" name="person" /></p>
    <p>Age: <jsp:getProperty property="age" name="person" /></p>
    
    <%-- JSP Forward Action --%>
    <jsp:forward page="anotherPage.jsp" />
    
    <%-- JSP Include Action --%>
    <jsp:include page="included.jsp" />
    
    <%-- JSP Plugin Action --%>
    <jsp:plugin type="applet" code="com.example.MyApplet" />
</body>
</html>


