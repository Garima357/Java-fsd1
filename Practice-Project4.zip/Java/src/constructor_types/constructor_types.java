package constructor_types;

public class constructor_types {
	private String Name;
	private int Age;
	
	public constructor_types() {
		this.Name = "unknown";
		this.Age = 0;
		
	}
	
	public constructor_types(String Name) {
		this.Name = "Name";
		this.Age = 0;
	}
	
	public constructor_types(String Name, int Age) {
		this.Name = "Name";
		this.Age = Age;
		
	}
	
	public void displayinfo() {
		System.out.println("name: " + Name);
		System.out.println("age: " + Age);
		
	}
	
	public static void main(String[] args) {
		
		constructor_types person1 = new constructor_types();
		System.out.println("Person 1:");
		person1.displayinfo();
		
		constructor_types person2 = new constructor_types("Tom");
		System.out.println("\nPerson 2:");
		person2.displayinfo();
		
		constructor_types person3 = new constructor_types("Tom", 30);
		System.out.println("\nPerson 3:");
		person2.displayinfo();
			
	}
	

}
