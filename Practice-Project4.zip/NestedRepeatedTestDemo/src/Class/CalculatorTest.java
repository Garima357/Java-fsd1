package Class;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class CalculatorTest {

    public static class AdditionTests {
        @Test
        public void testAdditionPositiveNumbers() {
            int result = add(2, 3);
            assertEquals(5, result);
        }

        @Test
        public void testAdditionZero() {
            int result = add(0, 0);
            assertEquals(0, result);
        }

        @Test
        public void testAdditionNegativeNumbers() {
            int result = add(-5, -3);
            assertEquals(-8, result);
        }
    }

    public static class SubtractionTests {
        @Test
        public void testSubtractionPositiveNumbers() {
            int result = subtract(5, 2);
            assertEquals(3, result);
        }

        @Test
        public void testSubtractionZero() {
            int result = subtract(10, 10);
            assertEquals(0, result);
        }

        @Test
        public void testSubtractionNegativeNumbers() {
            int result = subtract(-5, -3);
            assertEquals(-2, result);
        }
    }

    @Test
    public void testDivision() {
        int result = divide(10, 2);
        assertEquals(5, result);
    }

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int divide(int dividend, int divisor) {
        return dividend / divisor;
    }
}

