import OuterClass.inner_class;
import OuterClass.outer_class;



}
public class outer_class {
	private int outerData = 20;
	
	public int getOuterData() {
		return outerData;
	}
}

public class inner_class {
	public void display() {
		System.out.println("inner class method");
		outer_class outerObj = new outer_class();
		System.out.println("outer data: " + outerObj.getOuterData());
		
	}




public static void main(String[] args) {
	outer_class outerObj = new outer_class();
			inner_class innerObj = new inner_class();
			
			innerObj.display();
}
	
}
