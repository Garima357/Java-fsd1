import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUploadExample {
    public static void main(String[] args) {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
        
        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();
        
        // Navigate to a webpage with a file upload input field
        driver.get("https://example.com/upload");
        
        // Locate the file input element and send a file path
        WebElement fileInput = driver.findElement(By.id("file-upload-input"));
        fileInput.sendKeys("path_to_your_file.ext");
        
        // Trigger the file upload dialog by clicking a button (adjust the selector as needed)
        WebElement uploadButton = driver.findElement(By.id("upload-button"));
        uploadButton.click();
        
        // Execute the AutoIt script to handle the file upload dialog
        try {
            Runtime.getRuntime().exec("path/to/your_script.exe");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Close the WebDriver
        driver.quit();
    }
}
